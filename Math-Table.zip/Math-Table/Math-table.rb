system("cd Updater & GUP.exe")

system("color b")

system("cls")

# Banner and the developer name [::]

banner = File.read("banner.txt")
puts banner

puts ""

puts "                                                   By J0kEr64 / Yousef Hosam "

puts ""

puts "                                                                                v1.0"

puts ""

puts "Type the numbers >>>> "

n_num = 5

puts ""

print "First number : "

fir_num = gets.to_i

puts ""

print "Second number : "

s_num = gets.to_i

puts ""

print "Third number : "

t_num = gets.to_i

puts ""

print "Fourth number : "

fou_num = gets.to_i

puts ""

print "Fifth number : "

fif_num = gets.to_i

puts ""

# arithmetic mean calc >

sum_num = (fir_num + s_num + t_num + fou_num + fif_num).to_i

puts "The arithmetic mean"  + " = " + 
(sum_num / n_num).to_s  

puts ""

# arithmetic mean calc >>

mean = (sum_num / n_num).to_i 
fir_mean = (fir_num - mean).to_i
s_mean = (s_num - mean).to_i
t_mean = (t_num - mean).to_i
fou_mean = (fou_num - mean).to_i
fif_mean = (fif_num - mean).to_i

# aritmetic mean calc >>>

two = 2 
fir_end = (fir_mean ** two).to_i
s_end = (s_mean ** two).to_i
t_end = (t_mean ** two).to_i
fou_end = (fou_mean ** two).to_i
fif_end = (fif_mean ** two).to_i

# The total of (x-x̄)^2 >>>>

total = (fir_end + s_end + t_end + fou_end + fif_end).to_i

# Form of the table >>>>>

puts "============================================"                                                   
puts "=      x       =   x-x̄      =   (x-x̄)^2     "
puts "============================================"
puts "= #{fir_num}   =           #{fir_mean}            = #{fir_end}   "
puts "============================================"
puts "= #{s_num}     =           #{s_mean}              = #{s_end}     "
puts "============================================"
puts "= #{t_num}     =           #{t_mean}              = #{t_end}     "
puts "============================================"
puts "= #{fou_num}   =           #{fou_mean}            = #{fou_end}   "
puts "============================================"
puts "= #{fif_num}   =           #{fif_mean}            = #{fif_end}   "
puts "============================================"
puts "= The Total of (x-x̄)^2   =  #{total}    "
puts "=============================================="

puts ""

puts ""

print "Start Programe Again (y/n) >> "

cp = gets.chomp

####

if cp == "y"
	system("exit")
	system("start Math-table.rb")
elsif cp == "n"
	system("exit")
end

####

# To conatct send an email to lastman985@yahoo.com
# or go to joker64.github.io