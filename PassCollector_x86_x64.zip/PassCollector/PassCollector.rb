#
# [ T00l Name ]
#
# PassCollector
#
#  
# [ Author ] 
#
# JOKER64 / yousef hosam
#
#
# [ LICENSE ]
#
# GNU GENERAL PUBLIC LICENSE
# Version 3, 29 June 2007
#
#
# [ More Info ] 
#
# Go To :
#
# https://joker64.github.io/
#

banner = File.read("Banner")

puts banner

# Banner

puts "                             By JOKER64 / yousef hosam       " 

puts "                                                        v1.0 "

# Developer of the Tool

sleep(0.5)

   print ">The First name : "

    first_name = gets.chomp

     if first_name == ""
         puts "[-] You must enter The first name [-] "
         exit
    end

# [*] The txt will be named by the first name [*]

   print ">The Middle name : "

   middle_name = gets.chomp

   print ">The Last name : "

   last_name = gets.chomp

   print ">The Surname : "

   sur_name = gets.chomp

   print ">Nick name : "

   nick_name = gets.chomp

   print ">The Work Place : "

   work = gets.chomp

   print ">Birthdate (DDMMYYYY) : "

   birth = gets.chomp

   print ">Phone Numner : "
  
   phone = gets.chomp

#
# JOKER64
#

print ">The Partners name : "

partners_name = gets.chomp

print ">The Partners Birthdate (DDMMYYYY) : "

partners_date = gets.chomp

print ">Partners Phone : "

partners_phone = gets.chomp

print ">The Child's name : "

child_name = gets.chomp

print ">The Child's Nick name : "

child_nick = gets.chomp

print ">The Child's Birthdate (DDMMYYYY) : "

child_date = gets.chomp

print ">The Wife name : "

wife_name = gets.chomp

print ">The Wife Birthdate (DDMMYYYY) : "

wife_date = gets.chomp

print ">The Wife Work Place : "

wife_work = gets.chomp

print ">The Car type : "

car_type = gets.chomp

print ">The Car Model : "

car_model =gets.chomp

print ">The Pet's name : "

pet_name = gets.chomp

#
# end of questions -_-
#

#
# [+] The txt Password Genrating [+]
#


write_handler  = File.new("#{first_name}.txt", "w")

write_handler.puts(('!'..'*').to_a.shuffle[0,8].join)

write_handler.puts(('!'..'*').to_a.shuffle[0,8].join)

write_handler.puts(('!'..'*').to_a.shuffle[0,8].join)

write_handler.puts(('!'..'*').to_a.shuffle[0,8].join)

write_handler.puts(('!'..'*').to_a.shuffle[0,8].join)

write_handler.puts(('!'..'*').to_a.shuffle[0,8].join)

write_handler.puts(('!'..'*').to_a.shuffle[0,8].join)

write_handler.puts(('!'..'*').to_a.shuffle[0,8].join)

write_handler.puts(('!'..'*').to_a.shuffle[0,8].join)

# End of Symbols

write_handler.puts(('0'..'10').to_a.shuffle[0,8].join)

write_handler.puts(('0'..'20').to_a.shuffle[0,8].join)

write_handler.puts(('0'..'30').to_a.shuffle[0,8].join)

write_handler.puts(('0'..'50').to_a.shuffle[0,8].join)

# End of Numbers

write_handler.puts("#{first_name}")

write_handler.puts("#{middle_name}")

write_handler.puts("#{last_name}")

write_handler.puts("#{sur_name}")

write_handler.puts("#{nick_name}")

write_handler.puts("#{work}")

write_handler.puts("#{birth}")

write_handler.puts("#{phone}")

write_handler.puts("#{partners_name}")

write_handler.puts("#{partners_date}")

write_handler.puts("#{partners_phone}")

write_handler.puts("#{child_name}")

write_handler.puts("#{child_nick}")

write_handler.puts("#{child_date}")

write_handler.puts("#{wife_name}")

write_handler.puts("#{wife_date}")

write_handler.puts("#{wife_work}")

write_handler.puts("#{car_type}")

write_handler.puts("#{car_model}")

write_handler.puts("#{pet_name}")

# Strat Again

write_handler.puts(('a'..'z').to_a.shuffle[0,8].join)

write_handler.puts(('a'..'z').to_a.shuffle[0,8].join)

write_handler.puts(('a'..'z').to_a.shuffle[0,8].join)

write_handler.puts(('a'..'z').to_a.shuffle[0,8].join)

write_handler.puts(('a'..'z').to_a.shuffle[0,8].join)

write_handler.puts(('a'..'z').to_a.shuffle[0,8].join)

write_handler.puts(('a'..'z').to_a.shuffle[0,8].join)

write_handler.puts(('a'..'z').to_a.shuffle[0,8].join)

write_handler.puts(('a'..'z').to_a.shuffle[0,8].join)

write_handler.puts(('a'..'z').to_a.shuffle[0,8].join)

write_handler.puts(('a'..'z').to_a.shuffle[0,8].join)

write_handler.puts(('a'..'z').to_a.shuffle[0,8].join)

write_handler.puts(('a'..'z').to_a.shuffle[0,8].join)

write_handler.puts(('a'..'z').to_a.shuffle[0,8].join)

write_handler.puts(('a'..'z').to_a.shuffle[0,8].join)

write_handler.puts(('a'..'z').to_a.shuffle[0,8].join)

write_handler.puts(('a'..'z').to_a.shuffle[0,8].join)

write_handler.puts(('a'..'z').to_a.shuffle[0,8].join)

write_handler.puts(('a'..'z').to_a.shuffle[0,8].join)

write_handler.puts(('a'..'z').to_a.shuffle[0,8].join)

write_handler.puts(('a'..'z').to_a.shuffle[0,8].join)

write_handler.puts(('a'..'z').to_a.shuffle[0,8].join)

write_handler.puts(('a'..'z').to_a.shuffle[0,8].join)

write_handler.puts(('a'..'z').to_a.shuffle[0,8].join)

write_handler.puts(('a'..'z').to_a.shuffle[0,8].join)

write_handler.puts(('a'..'z').to_a.shuffle[0,8].join)

write_handler.puts(('a'..'z').to_a.shuffle[0,8].join)

write_handler.puts(('a'..'z').to_a.shuffle[0,8].join)

write_handler.puts(('a'..'z').to_a.shuffle[0,8].join)

write_handler.puts(('a'..'z').to_a.shuffle[0,8].join)

write_handler.puts(('a'..'z').to_a.shuffle[0,8].join)

write_handler.puts(('a'..'z').to_a.shuffle[0,8].join)

write_handler.puts(('a'..'z').to_a.shuffle[0,8].join)

write_handler.puts(('a'..'z').to_a.shuffle[0,8].join)

write_handler.puts(('a'..'z').to_a.shuffle[0,8].join)

write_handler.puts(('a'..'z').to_a.shuffle[0,8].join)

write_handler.puts(('a'..'z').to_a.shuffle[0,8].join)

write_handler.puts(('a'..'z').to_a.shuffle[0,8].join)

write_handler.puts(('a'..'z').to_a.shuffle[0,8].join)

write_handler.puts(('a'..'z').to_a.shuffle[0,8].join)

write_handler.puts(('a'..'z').to_a.shuffle[0,8].join)

write_handler.puts(('a'..'z').to_a.shuffle[0,8].join)

write_handler.puts(('a'..'z').to_a.shuffle[0,8].join)

write_handler.puts(('a'..'z').to_a.shuffle[0,8].join)

write_handler.puts(('a'..'z').to_a.shuffle[0,8].join)

write_handler.puts(('a'..'z').to_a.shuffle[0,8].join)

write_handler.puts(('a'..'z').to_a.shuffle[0,8].join)

write_handler.puts(('a'..'z').to_a.shuffle[0,8].join)


#
# JOKER64
#

write_handler.puts(('!'..'*').to_a.shuffle[0,8].join)

write_handler.puts(('!'..'*').to_a.shuffle[0,8].join)

write_handler.puts(('!'..'*').to_a.shuffle[0,8].join)

write_handler.puts(('!'..'*').to_a.shuffle[0,8].join)

write_handler.puts(('!'..'*').to_a.shuffle[0,8].join)

write_handler.puts(('!'..'*').to_a.shuffle[0,8].join)

write_handler.puts(('!'..'*').to_a.shuffle[0,8].join)

write_handler.puts(('!'..'*').to_a.shuffle[0,8].join)

write_handler.puts(('!'..'*').to_a.shuffle[0,8].join)

write_handler.puts(('!'..'*').to_a.shuffle[0,8].join)

write_handler.puts(('!'..'*').to_a.shuffle[0,8].join)

write_handler.puts(('!'..'*').to_a.shuffle[0,8].join)

write_handler.puts(('!'..'*').to_a.shuffle[0,8].join)

write_handler.puts(('!'..'*').to_a.shuffle[0,8].join)

write_handler.puts(('!'..'*').to_a.shuffle[0,8].join)

write_handler.puts(('!'..'*').to_a.shuffle[0,8].join)

write_handler.puts(('!'..'*').to_a.shuffle[0,8].join)

write_handler.puts(('!'..'*').to_a.shuffle[0,8].join)

write_handler.puts(('!'..'*').to_a.shuffle[0,8].join)

write_handler.puts(('!'..'*').to_a.shuffle[0,8].join)

write_handler.puts(('!'..'*').to_a.shuffle[0,8].join)

write_handler.puts(('!'..'*').to_a.shuffle[0,8].join)

write_handler.puts(('!'..'*').to_a.shuffle[0,8].join)

write_handler.puts(('!'..'*').to_a.shuffle[0,8].join)

write_handler.puts(('!'..'*').to_a.shuffle[0,8].join)

write_handler.puts(('!'..'*').to_a.shuffle[0,8].join)

write_handler.puts(('!'..'*').to_a.shuffle[0,8].join)

write_handler.puts(('!'..'*').to_a.shuffle[0,8].join)

write_handler.puts(('!'..'*').to_a.shuffle[0,8].join)

write_handler.puts(('!'..'*').to_a.shuffle[0,8].join)

write_handler.puts(('!'..'*').to_a.shuffle[0,8].join)

write_handler.puts(('!'..'*').to_a.shuffle[0,8].join)

write_handler.puts(('!'..'*').to_a.shuffle[0,8].join)

write_handler.puts(('!'..'*').to_a.shuffle[0,8].join)

write_handler.puts(('!'..'*').to_a.shuffle[0,8].join)

write_handler.puts(('!'..'*').to_a.shuffle[0,8].join)

write_handler.puts(('!'..'*').to_a.shuffle[0,8].join)

write_handler.puts(('!'..'*').to_a.shuffle[0,8].join)

write_handler.puts(('!'..'*').to_a.shuffle[0,8].join)

write_handler.puts(('!'..'*').to_a.shuffle[0,8].join)

write_handler.puts(('!'..'*').to_a.shuffle[0,8].join)

write_handler.puts(('!'..'*').to_a.shuffle[0,8].join)

write_handler.puts(('!'..'*').to_a.shuffle[0,8].join)

write_handler.puts(('!'..'*').to_a.shuffle[0,8].join)

write_handler.puts(('!'..'*').to_a.shuffle[0,8].join)

write_handler.puts(('!'..'*').to_a.shuffle[0,8].join)

write_handler.puts(('!'..'*').to_a.shuffle[0,8].join)

write_handler.puts(('!'..'*').to_a.shuffle[0,8].join)

write_handler.puts(('!'..'*').to_a.shuffle[0,8].join)

write_handler.puts(('!'..'*').to_a.shuffle[0,8].join)

write_handler.puts(('!'..'*').to_a.shuffle[0,8].join)

write_handler.puts(('!'..'*').to_a.shuffle[0,8].join)

write_handler.puts(('!'..'*').to_a.shuffle[0,8].join)

write_handler.puts(('!'..'*').to_a.shuffle[0,8].join)

write_handler.puts(('!'..'*').to_a.shuffle[0,8].join)

write_handler.puts(('!'..'*').to_a.shuffle[0,8].join)

write_handler.puts(('!'..'*').to_a.shuffle[0,8].join)

write_handler.puts(('!'..'*').to_a.shuffle[0,8].join)

write_handler.puts(('!'..'*').to_a.shuffle[0,8].join)

write_handler.puts(('!'..'*').to_a.shuffle[0,8].join)

write_handler.puts(('!'..'*').to_a.shuffle[0,8].join)

write_handler.puts(('!'..'*').to_a.shuffle[0,8].join)

write_handler.puts(('!'..'*').to_a.shuffle[0,8].join)

write_handler.puts(('!'..'*').to_a.shuffle[0,8].join)

write_handler.puts(('!'..'*').to_a.shuffle[0,8].join)

write_handler.puts(('!'..'*').to_a.shuffle[0,8].join)

write_handler.puts(('!'..'*').to_a.shuffle[0,8].join)

write_handler.puts(('!'..'*').to_a.shuffle[0,8].join)

write_handler.puts(('!'..'*').to_a.shuffle[0,8].join)

write_handler.puts(('!'..'*').to_a.shuffle[0,8].join)

write_handler.puts(('!'..'*').to_a.shuffle[0,8].join)

write_handler.puts(('!'..'*').to_a.shuffle[0,8].join)

write_handler.puts(('!'..'*').to_a.shuffle[0,8].join)

write_handler.puts(('!'..'*').to_a.shuffle[0,8].join)

write_handler.puts(('!'..'*').to_a.shuffle[0,8].join)

write_handler.puts(('!'..'*').to_a.shuffle[0,8].join)

write_handler.puts(('!'..'*').to_a.shuffle[0,8].join)

write_handler.puts(('!'..'*').to_a.shuffle[0,8].join)

write_handler.puts(('!'..'*').to_a.shuffle[0,8].join)

write_handler.puts(('!'..'*').to_a.shuffle[0,8].join)

write_handler.puts(('!'..'*').to_a.shuffle[0,8].join)

write_handler.puts(('!'..'*').to_a.shuffle[0,8].join)

write_handler.puts(('!'..'*').to_a.shuffle[0,8].join)

write_handler.puts(('!'..'*').to_a.shuffle[0,8].join)

write_handler.puts(('!'..'*').to_a.shuffle[0,8].join)

write_handler.puts(('!'..'*').to_a.shuffle[0,8].join)

write_handler.puts(('!'..'*').to_a.shuffle[0,8].join)

write_handler.puts(('!'..'*').to_a.shuffle[0,8].join)

write_handler.puts(('!'..'*').to_a.shuffle[0,8].join)

write_handler.puts(('!'..'*').to_a.shuffle[0,8].join)

write_handler.puts(('!'..'*').to_a.shuffle[0,8].join)

write_handler.puts(('!'..'*').to_a.shuffle[0,8].join)

write_handler.puts(('!'..'*').to_a.shuffle[0,8].join)

write_handler.puts(('!'..'*').to_a.shuffle[0,8].join)

write_handler.puts(('!'..'*').to_a.shuffle[0,8].join)

write_handler.puts(('!'..'*').to_a.shuffle[0,8].join)

write_handler.puts(('!'..'*').to_a.shuffle[0,8].join)

write_handler.puts(('!'..'*').to_a.shuffle[0,8].join)

write_handler.puts(('!'..'*').to_a.shuffle[0,8].join)

write_handler.puts(('!'..'*').to_a.shuffle[0,8].join)

write_handler.puts(('!'..'*').to_a.shuffle[0,8].join)

write_handler.puts(('!'..'*').to_a.shuffle[0,8].join)

write_handler.puts(('!'..'*').to_a.shuffle[0,8].join)

write_handler.puts(('!'..'*').to_a.shuffle[0,8].join)

write_handler.puts(('!'..'*').to_a.shuffle[0,8].join)

write_handler.puts(('!'..'*').to_a.shuffle[0,8].join)

write_handler.puts(('!'..'*').to_a.shuffle[0,8].join)

write_handler.puts(('!'..'*').to_a.shuffle[0,8].join)


#
# JOKER64 / yousef hosam
#

write_handler.puts(('0'..'10').to_a.shuffle[0,8].join)

write_handler.puts(('0'..'20').to_a.shuffle[0,8].join)

write_handler.puts(('0'..'30').to_a.shuffle[0,8].join)

write_handler.puts(('0'..'50').to_a.shuffle[0,8].join)

write_handler.puts(('0'..'10').to_a.shuffle[0,8].join)

write_handler.puts(('0'..'20').to_a.shuffle[0,8].join)

write_handler.puts(('0'..'30').to_a.shuffle[0,8].join)

write_handler.puts(('0'..'50').to_a.shuffle[0,8].join)

write_handler.puts(('0'..'10').to_a.shuffle[0,8].join)

write_handler.puts(('0'..'20').to_a.shuffle[0,8].join)

write_handler.puts(('0'..'30').to_a.shuffle[0,8].join)

write_handler.puts(('0'..'50').to_a.shuffle[0,8].join)

write_handler.puts(('0'..'10').to_a.shuffle[0,8].join)

write_handler.puts(('0'..'20').to_a.shuffle[0,8].join)

write_handler.puts(('0'..'30').to_a.shuffle[0,8].join)

write_handler.puts(('0'..'50').to_a.shuffle[0,8].join)

write_handler.puts(('0'..'10').to_a.shuffle[0,8].join)

write_handler.puts(('0'..'20').to_a.shuffle[0,8].join)

write_handler.puts(('0'..'30').to_a.shuffle[0,8].join)

write_handler.puts(('0'..'50').to_a.shuffle[0,8].join)

write_handler.puts(('0'..'10').to_a.shuffle[0,8].join)

write_handler.puts(('0'..'20').to_a.shuffle[0,8].join)

write_handler.puts(('0'..'30').to_a.shuffle[0,8].join)

write_handler.puts(('0'..'50').to_a.shuffle[0,8].join)

write_handler.puts(('0'..'10').to_a.shuffle[0,8].join)

write_handler.puts(('0'..'20').to_a.shuffle[0,8].join)

write_handler.puts(('0'..'30').to_a.shuffle[0,8].join)

write_handler.puts(('0'..'50').to_a.shuffle[0,8].join)

write_handler.puts(('0'..'10').to_a.shuffle[0,8].join)

write_handler.puts(('0'..'20').to_a.shuffle[0,8].join)

write_handler.puts(('0'..'30').to_a.shuffle[0,8].join)

write_handler.puts(('0'..'50').to_a.shuffle[0,8].join)

write_handler.puts(('0'..'10').to_a.shuffle[0,8].join)

write_handler.puts(('0'..'20').to_a.shuffle[0,8].join)

write_handler.puts(('0'..'30').to_a.shuffle[0,8].join)

write_handler.puts(('0'..'50').to_a.shuffle[0,8].join)

write_handler.puts(('0'..'10').to_a.shuffle[0,8].join)

write_handler.puts(('0'..'20').to_a.shuffle[0,8].join)

write_handler.puts(('0'..'30').to_a.shuffle[0,8].join)

write_handler.puts(('0'..'50').to_a.shuffle[0,8].join)

write_handler.puts(('0'..'10').to_a.shuffle[0,8].join)

write_handler.puts(('0'..'20').to_a.shuffle[0,8].join)

write_handler.puts(('0'..'30').to_a.shuffle[0,8].join)

write_handler.puts(('0'..'50').to_a.shuffle[0,8].join)

write_handler.puts(('0'..'10').to_a.shuffle[0,8].join)

write_handler.puts(('0'..'20').to_a.shuffle[0,8].join)

write_handler.puts(('0'..'30').to_a.shuffle[0,8].join)

write_handler.puts(('0'..'50').to_a.shuffle[0,8].join)

write_handler.puts(('0'..'10').to_a.shuffle[0,8].join)

write_handler.puts(('0'..'20').to_a.shuffle[0,8].join)

write_handler.puts(('0'..'30').to_a.shuffle[0,8].join)

write_handler.puts(('0'..'50').to_a.shuffle[0,8].join)

write_handler.puts(('0'..'10').to_a.shuffle[0,8].join)

write_handler.puts(('0'..'20').to_a.shuffle[0,8].join)

write_handler.puts(('0'..'30').to_a.shuffle[0,8].join)

write_handler.puts(('0'..'50').to_a.shuffle[0,8].join)

write_handler.puts(('0'..'10').to_a.shuffle[0,8].join)

write_handler.puts(('0'..'20').to_a.shuffle[0,8].join)

write_handler.puts(('0'..'30').to_a.shuffle[0,8].join)

write_handler.puts(('0'..'50').to_a.shuffle[0,8].join)

write_handler.puts(('0'..'10').to_a.shuffle[0,8].join)

write_handler.puts(('0'..'20').to_a.shuffle[0,8].join)

write_handler.puts(('0'..'30').to_a.shuffle[0,8].join)

write_handler.puts(('0'..'50').to_a.shuffle[0,8].join)

write_handler.puts(('0'..'10').to_a.shuffle[0,8].join)

write_handler.puts(('0'..'20').to_a.shuffle[0,8].join)

write_handler.puts(('0'..'30').to_a.shuffle[0,8].join)

write_handler.puts(('0'..'50').to_a.shuffle[0,8].join)

write_handler.puts(('0'..'10').to_a.shuffle[0,8].join)

write_handler.puts(('0'..'20').to_a.shuffle[0,8].join)

write_handler.puts(('0'..'30').to_a.shuffle[0,8].join)

write_handler.puts(('0'..'50').to_a.shuffle[0,8].join)

write_handler.puts(('0'..'10').to_a.shuffle[0,8].join)

write_handler.puts(('0'..'20').to_a.shuffle[0,8].join)

write_handler.puts(('0'..'30').to_a.shuffle[0,8].join)

write_handler.puts(('0'..'50').to_a.shuffle[0,8].join)

write_handler.puts(('0'..'10').to_a.shuffle[0,8].join)

write_handler.puts(('0'..'20').to_a.shuffle[0,8].join)

write_handler.puts(('0'..'30').to_a.shuffle[0,8].join)

write_handler.puts(('0'..'50').to_a.shuffle[0,8].join)

write_handler.puts(('0'..'10').to_a.shuffle[0,8].join)

write_handler.puts(('0'..'20').to_a.shuffle[0,8].join)

write_handler.puts(('0'..'30').to_a.shuffle[0,8].join)

write_handler.puts(('0'..'50').to_a.shuffle[0,8].join)


write_handler.puts(('0'..'10').to_a.shuffle[0,8].join)

write_handler.puts(('0'..'20').to_a.shuffle[0,8].join)

write_handler.puts(('0'..'30').to_a.shuffle[0,8].join)

write_handler.puts(('0'..'50').to_a.shuffle[0,8].join)

write_handler.puts(('0'..'10').to_a.shuffle[0,8].join)

write_handler.puts(('0'..'20').to_a.shuffle[0,8].join)

write_handler.puts(('0'..'30').to_a.shuffle[0,8].join)

write_handler.puts(('0'..'50').to_a.shuffle[0,8].join)

write_handler.puts(('0'..'10').to_a.shuffle[0,8].join)

write_handler.puts(('0'..'20').to_a.shuffle[0,8].join)

write_handler.puts(('0'..'30').to_a.shuffle[0,8].join)

write_handler.puts(('0'..'50').to_a.shuffle[0,8].join)

write_handler.puts(('0'..'10').to_a.shuffle[0,8].join)

write_handler.puts(('0'..'20').to_a.shuffle[0,8].join)

write_handler.puts(('0'..'30').to_a.shuffle[0,8].join)

write_handler.puts(('0'..'50').to_a.shuffle[0,8].join)

write_handler.puts(('0'..'10').to_a.shuffle[0,8].join)

write_handler.puts(('0'..'20').to_a.shuffle[0,8].join)

write_handler.puts(('0'..'30').to_a.shuffle[0,8].join)

write_handler.puts(('0'..'50').to_a.shuffle[0,8].join)

write_handler.puts(('0'..'10').to_a.shuffle[0,8].join)

write_handler.puts(('0'..'20').to_a.shuffle[0,8].join)

write_handler.puts(('0'..'30').to_a.shuffle[0,8].join)

write_handler.puts(('0'..'50').to_a.shuffle[0,8].join)

write_handler.puts(('0'..'10').to_a.shuffle[0,8].join)

write_handler.puts(('0'..'20').to_a.shuffle[0,8].join)

write_handler.puts(('0'..'30').to_a.shuffle[0,8].join)

write_handler.puts(('0'..'50').to_a.shuffle[0,8].join)

write_handler.puts(('0'..'10').to_a.shuffle[0,8].join)

write_handler.puts(('0'..'20').to_a.shuffle[0,8].join)

write_handler.puts(('0'..'30').to_a.shuffle[0,8].join)

write_handler.puts(('0'..'50').to_a.shuffle[0,8].join)

write_handler.puts(('0'..'10').to_a.shuffle[0,8].join)

write_handler.puts(('0'..'20').to_a.shuffle[0,8].join)

write_handler.puts(('0'..'30').to_a.shuffle[0,8].join)

write_handler.puts(('0'..'50').to_a.shuffle[0,8].join)

write_handler.puts(('0'..'10').to_a.shuffle[0,8].join)

write_handler.puts(('0'..'20').to_a.shuffle[0,8].join)

write_handler.puts(('0'..'30').to_a.shuffle[0,8].join)

write_handler.puts(('0'..'50').to_a.shuffle[0,8].join)

write_handler.puts(('0'..'10').to_a.shuffle[0,8].join)

write_handler.puts(('0'..'20').to_a.shuffle[0,8].join)

write_handler.puts(('0'..'30').to_a.shuffle[0,8].join)

write_handler.puts(('0'..'50').to_a.shuffle[0,8].join)

write_handler.puts(('0'..'10').to_a.shuffle[0,8].join)

write_handler.puts(('0'..'20').to_a.shuffle[0,8].join)

write_handler.puts(('0'..'30').to_a.shuffle[0,8].join)

write_handler.puts(('0'..'50').to_a.shuffle[0,8].join)

write_handler.puts(('0'..'10').to_a.shuffle[0,8].join)

write_handler.puts(('0'..'20').to_a.shuffle[0,8].join)

write_handler.puts(('0'..'30').to_a.shuffle[0,8].join)

write_handler.puts(('0'..'50').to_a.shuffle[0,8].join)

write_handler.puts(('0'..'10').to_a.shuffle[0,8].join)

write_handler.puts(('0'..'20').to_a.shuffle[0,8].join)

write_handler.puts(('0'..'30').to_a.shuffle[0,8].join)

write_handler.puts(('0'..'50').to_a.shuffle[0,8].join)

write_handler.puts(('0'..'10').to_a.shuffle[0,8].join)

write_handler.puts(('0'..'20').to_a.shuffle[0,8].join)

write_handler.puts(('0'..'30').to_a.shuffle[0,8].join)

write_handler.puts(('0'..'50').to_a.shuffle[0,8].join)

write_handler.puts(('0'..'10').to_a.shuffle[0,8].join)

write_handler.puts(('0'..'20').to_a.shuffle[0,8].join)

write_handler.puts(('0'..'30').to_a.shuffle[0,8].join)

write_handler.puts(('0'..'50').to_a.shuffle[0,8].join)

write_handler.puts(('0'..'10').to_a.shuffle[0,8].join)

write_handler.puts(('0'..'20').to_a.shuffle[0,8].join)

write_handler.puts(('0'..'30').to_a.shuffle[0,8].join)

write_handler.puts(('0'..'50').to_a.shuffle[0,8].join)

write_handler.puts(('0'..'10').to_a.shuffle[0,8].join)

write_handler.puts(('0'..'20').to_a.shuffle[0,8].join)

write_handler.puts(('0'..'30').to_a.shuffle[0,8].join)

write_handler.puts(('0'..'50').to_a.shuffle[0,8].join)

write_handler.puts(('0'..'10').to_a.shuffle[0,8].join)

write_handler.puts(('0'..'20').to_a.shuffle[0,8].join)

write_handler.puts(('0'..'30').to_a.shuffle[0,8].join)

write_handler.puts(('0'..'50').to_a.shuffle[0,8].join)

write_handler.puts(('0'..'10').to_a.shuffle[0,8].join)

write_handler.puts(('0'..'20').to_a.shuffle[0,8].join)

write_handler.puts(('0'..'30').to_a.shuffle[0,8].join)

write_handler.puts(('0'..'50').to_a.shuffle[0,8].join)

write_handler.puts(('0'..'10').to_a.shuffle[0,8].join)

write_handler.puts(('0'..'20').to_a.shuffle[0,8].join)

write_handler.puts(('0'..'30').to_a.shuffle[0,8].join)

write_handler.puts(('0'..'50').to_a.shuffle[0,8].join)

#
# 0ne More Time
#

write_handler.puts("#{first_name}")

write_handler.puts("#{middle_name}")

write_handler.puts("#{last_name}")

write_handler.puts("#{sur_name}")

write_handler.puts("#{nick_name}")

write_handler.puts("#{work}")

write_handler.puts("#{birth}")

write_handler.puts("#{phone}")

write_handler.puts("#{partners_name}")

write_handler.puts("#{partners_date}")

write_handler.puts("#{partners_phone}")

write_handler.puts("#{child_name}")

write_handler.puts("#{child_nick}")

write_handler.puts("#{child_date}")

write_handler.puts("#{wife_name}")

write_handler.puts("#{wife_date}")

write_handler.puts("#{wife_work}")

write_handler.puts("#{car_type}")

write_handler.puts("#{car_model}")

write_handler.puts("#{pet_name}")

write_handler.puts(('a'..'z').to_a.shuffle[0,8].join)

write_handler.puts(('a'..'z').to_a.shuffle[0,8].join)

write_handler.puts(('a'..'z').to_a.shuffle[0,8].join)

write_handler.puts(('a'..'z').to_a.shuffle[0,8].join)

write_handler.puts(('a'..'z').to_a.shuffle[0,8].join)

write_handler.puts(('a'..'z').to_a.shuffle[0,8].join)

write_handler.puts(('a'..'z').to_a.shuffle[0,8].join)

write_handler.puts(('a'..'z').to_a.shuffle[0,8].join)

write_handler.puts(('a'..'z').to_a.shuffle[0,8].join)

write_handler.puts(('a'..'z').to_a.shuffle[0,8].join)

write_handler.puts(('a'..'z').to_a.shuffle[0,8].join)

write_handler.puts(('a'..'z').to_a.shuffle[0,8].join)

write_handler.puts(('a'..'z').to_a.shuffle[0,8].join)

write_handler.puts(('a'..'z').to_a.shuffle[0,8].join)

write_handler.puts(('a'..'z').to_a.shuffle[0,8].join)

write_handler.puts(('a'..'z').to_a.shuffle[0,8].join)

write_handler.puts(('0'..'8').to_a.shuffle[0,8].join)

write_handler.puts(('0'..'8').to_a.shuffle[0,8].join)

write_handler.puts(('0'..'8').to_a.shuffle[0,8].join)

write_handler.puts(('0'..'8').to_a.shuffle[0,8].join)

write_handler.puts(('0'..'8').to_a.shuffle[0,8].join)

write_handler.puts(('0'..'8').to_a.shuffle[0,8].join)

write_handler.puts(('0'..'8').to_a.shuffle[0,8].join)

write_handler.puts(('0'..'8').to_a.shuffle[0,8].join)

write_handler.puts(('0'..'8').to_a.shuffle[0,8].join)

write_handler.puts(('0'..'12').to_a.shuffle[0,8].join)

write_handler.puts(('0'..'12').to_a.shuffle[0,8].join)

write_handler.puts(('0'..'12').to_a.shuffle[0,8].join)

write_handler.puts(('0'..'12').to_a.shuffle[0,8].join)

write_handler.puts(('0'..'12').to_a.shuffle[0,8].join)

write_handler.puts(('0'..'12').to_a.shuffle[0,8].join)

write_handler.puts(('0'..'12').to_a.shuffle[0,8].join)

write_handler.puts(('0'..'12').to_a.shuffle[0,8].join)

write_handler.puts(('0'..'12').to_a.shuffle[0,8].join)

write_handler.puts("123456")

write_handler.puts("123456789")

write_handler.puts("qwerty")

write_handler.puts("12345678")

write_handler.puts("111111")

write_handler.puts("1234567890")

write_handler.puts("1234567")

write_handler.puts("password")

write_handler.puts("123123")

write_handler.puts("987654321")

write_handler.puts("qwertyuiop")

write_handler.puts("mynoob")

write_handler.puts("123321")

write_handler.puts("666666")

write_handler.puts("18atcskd2w")

write_handler.puts("7777777")

write_handler.puts("1q2w3e4r")

write_handler.puts("654321")

write_handler.puts("555555")

write_handler.puts("3rjs1la7qe")

write_handler.puts("google")

write_handler.puts("1q2w3e4r5t")

write_handler.puts("123qwe")

write_handler.puts("zxcvbnm")

write_handler.puts("1q2w3e")


#
#
# End of TXT *_*
# JOKER64 / yousef hosam
#
#


puts "[+] PassCollector Add some Numbers,Symboles and Letters [+] "


# [+] quit [+]


puts "[*]..PassCollector Turned off Good Bye.. [*] "


#
#
# Good Bye 
#
#
