# PAYLOAD-MAKER
Genrating  PAYLOAD  Automatically for Windows & Android [*]For Now[*]
# Tested on
<table>
    <tr>
        <th>Operative system</th>
        <th> Version </th>
    </tr>
    <tr>
        <td>Kali linux</td>
        <td> Rolling / Sana</td>
    </tr>
</table>

# Installing :
Open terminal then : git clone https://github.com/joker64/PAYLOAD-MAKER.git 

# How To Use :
go to the directory of PAYLOAD-MAKER & open terminal<br>
then : ruby PAYLOADMAKER.rb &<br> 
Chose the type of payload<br>
set your LHOST = your Ip Address.<br>
set your LPORT = the port of listener.<br>
Location of payload = the location that you want for the payload.<br>
and wait for the payload to genrate.<br>
